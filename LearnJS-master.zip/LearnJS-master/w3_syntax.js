/**
 * Filename: e:\LearnJS\w3_syntax.js
 * Path: e:\LearnJS
 * Created Date: Monday, February 12th 2018, 1:05:52 pm
 * Author: AliHusain Sorathiya
 * 
 * Copyright (c) 2018 Your Company
 */


 var x, y;
 x =5; y =6;
 z=x+y;
 console.log(z);
