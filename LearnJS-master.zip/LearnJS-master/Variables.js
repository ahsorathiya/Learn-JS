/**
 * Filename: e:\LearnJS\Variables.js
 * Path: e:\LearnJS
 * Created Date: Monday, February 5th 2018, 1:06:30 pm
 * Author: AliHusain Sorathiya
 * 
 * Copyright (c) 2018 Your Company
 */

x2=2;
console.log(x2);
var x=1;
console.log(x);
