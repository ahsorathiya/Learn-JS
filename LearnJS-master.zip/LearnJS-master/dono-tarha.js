/**
 * Filename: e:\LearnJS\dono-tarha.js
 * Path: e:\LearnJS
 * Created Date: Tuesday, February 6th 2018, 4:53:07 pm
 * Author: AliHusain Sorathiya
 * 
 * Copyright (c) 2018 Your Company
 */


//1st method

function print(msg) {
    console.log("Hello" + msg);
}

console.log("-------First Method-------");
print("first method Zaala");
// second object
// hello is key. function is Value//

var Hello = function (msg) {
console.log("Hello "+ msg);
};
console.log("-------Second Method-------");
Hello("Second method Zaala");