/**
 * Filename: e:\LearnJS\w3_jsfunctions.js
 * Path: e:\LearnJS
 * Created Date: Monday, February 12th 2018, 1:16:57 pm
 * Author: AliHusain Sorathiya
 * 
 * Copyright (c) 2018 Your Company
 */

function multiply(a,b,c) {
    var z = a*b*c;
console.log("program ends");
console.log(c);
return z;

}
var result = multiply(5,2,7);
console.log(result);
// var multiply = 100;
// console.log(multiply);
// var secondresult = multiply(5,10);
// console.log(secondresult);

var d = new Date();
d.getDate();

d.getMonth();
d.getFullYear();
console.log("asdasds");
