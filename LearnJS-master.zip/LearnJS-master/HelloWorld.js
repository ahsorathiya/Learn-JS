/**
 * Filename: e:\LearnJS\HelloWorld.js
 * Path: e:\LearnJS
 * Created Date: Monday, February 5th 2018, 11:23:26 am
 * Author: AliHusain Sorathiya
 * 
 * Copyright (c) 2018 Your Company
 */


console.log("Hello World");
